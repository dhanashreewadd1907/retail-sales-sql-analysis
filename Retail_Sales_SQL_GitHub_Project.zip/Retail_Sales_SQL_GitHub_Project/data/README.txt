Download the dataset CSV from the Kaggle source linked in the root README and place it here for local use. CSV files are ignored by Git.
