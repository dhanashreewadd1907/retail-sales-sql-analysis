/* ============================================================
3. OVERALL BUSINESS KPIs
============================================================ */

-- 3.1 Sales performance overview
SELECT
    COUNT(*) AS total_transactions,
    COUNT(DISTINCT customer_id) AS total_customers,
    SUM(quantity) AS total_units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value,
    ROUND(AVG(age), 2) AS average_customer_age
FROM retail_sales;


-- 3.2 Highest and lowest transaction values
SELECT MAX(total_amount) AS highest_transaction,
       MIN(total_amount) AS lowest_transaction
FROM retail_sales;
