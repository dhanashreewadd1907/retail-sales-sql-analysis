/* ============================================================
8. CATEGORY x GENDER ANALYSIS
============================================================ */

-- 8.1 Transaction and revenue comparison by category and gender
SELECT
    product_category,
    gender,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY product_category, gender
ORDER BY product_category, total_revenue DESC;
