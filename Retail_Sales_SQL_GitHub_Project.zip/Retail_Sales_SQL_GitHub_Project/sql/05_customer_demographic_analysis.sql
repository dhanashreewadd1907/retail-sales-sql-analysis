/* ============================================================
5. CUSTOMER & DEMOGRAPHIC ANALYSIS
============================================================ */

-- 5.1 Sales performance by gender
SELECT
    gender,
    COUNT(*) AS transactions,
    COUNT(DISTINCT customer_id) AS unique_customers,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY gender
ORDER BY total_revenue DESC;


-- 5.2 Customer age group analysis
SELECT
    CASE
        WHEN age < 18 THEN 'Under 18'
        WHEN age BETWEEN 18 AND 25 THEN '18-25'
        WHEN age BETWEEN 26 AND 35 THEN '26-35'
        WHEN age BETWEEN 36 AND 45 THEN '36-45'
        WHEN age BETWEEN 46 AND 55 THEN '46-55'
        ELSE '56+'
    END AS age_group,
    COUNT(*) AS transactions,
    COUNT(DISTINCT customer_id) AS unique_customers,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY age_group
ORDER BY total_revenue DESC;


-- 5.3 Top 10 customers by revenue
SELECT
    customer_id,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_purchased,
    SUM(total_amount) AS total_spent
FROM retail_sales
GROUP BY customer_id
ORDER BY total_spent DESC
LIMIT 10;


-- 5.4 Customers with above-average total spending
SELECT customer_id,
       SUM(total_amount) AS customer_total_spending
FROM retail_sales
GROUP BY customer_id
HAVING SUM(total_amount) > (
    SELECT AVG(customer_spending)
    FROM (
        SELECT SUM(total_amount) AS customer_spending
        FROM retail_sales
        GROUP BY customer_id
    ) AS customer_totals
)
ORDER BY customer_total_spending DESC;
