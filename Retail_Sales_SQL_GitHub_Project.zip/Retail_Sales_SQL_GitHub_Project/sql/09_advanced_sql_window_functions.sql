/* ============================================================
9. ADVANCED SQL - RANKING & WINDOW FUNCTIONS
============================================================ */

-- 9.1 Rank product categories by revenue
SELECT
    product_category,
    SUM(total_amount) AS category_revenue,
    RANK() OVER (ORDER BY SUM(total_amount) DESC) AS revenue_rank
FROM retail_sales
GROUP BY product_category;


-- 9.2 Rank customers by total spending
WITH customer_revenue AS (
    SELECT customer_id,
           SUM(total_amount) AS total_spending
    FROM retail_sales
    GROUP BY customer_id
)
SELECT customer_id,
       total_spending,
       DENSE_RANK() OVER (ORDER BY total_spending DESC) AS customer_rank
FROM customer_revenue
ORDER BY customer_rank
LIMIT 20;


-- 9.3 Running monthly revenue total
WITH monthly_revenue AS (
    SELECT DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
           SUM(total_amount) AS revenue
    FROM retail_sales
    GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
)
SELECT year_month,
       revenue,
       SUM(revenue) OVER (ORDER BY year_month) AS running_revenue
FROM monthly_revenue
ORDER BY year_month;


-- 9.4 Revenue change compared with previous month
WITH monthly_revenue AS (
    SELECT DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
           SUM(total_amount) AS revenue
    FROM retail_sales
    GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
)
SELECT year_month,
       revenue,
       LAG(revenue) OVER (ORDER BY year_month) AS previous_month_revenue,
       revenue - LAG(revenue) OVER (ORDER BY year_month) AS revenue_difference
FROM monthly_revenue
ORDER BY year_month;


/* ============================================================
10. BUSINESS QUESTIONS TO ANSWER IN PROJECT README
============================================================
1. How many transactions and unique customers are in the dataset?
2. What is the total revenue and average transaction value?
3. Which product category generates the highest revenue?
4. Which category has the highest transaction count?
5. Which gender group contributes more revenue?
6. Which customer age group contributes the most revenue?
7. Who are the top 10 customers by spending?
8. Which month generates the highest revenue?
9. Which day of the week has the highest revenue?
10. Which transactions have the highest value?
11. How do monthly revenues change over time?
12. Which categories perform best for each gender?

End of project script.
*/
