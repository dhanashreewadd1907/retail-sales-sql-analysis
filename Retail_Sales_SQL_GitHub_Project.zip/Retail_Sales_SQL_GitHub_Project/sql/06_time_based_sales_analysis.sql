/* ============================================================
6. TIME-BASED SALES ANALYSIS
============================================================ */

-- 6.1 Revenue by year and month
SELECT
    YEAR(sale_date) AS sales_year,
    MONTH(sale_date) AS sales_month,
    DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS monthly_revenue
FROM retail_sales
GROUP BY YEAR(sale_date), MONTH(sale_date), DATE_FORMAT(sale_date, '%Y-%m')
ORDER BY sales_year, sales_month;


-- 6.2 Best revenue month overall
SELECT
    DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
    SUM(total_amount) AS monthly_revenue
FROM retail_sales
GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
ORDER BY monthly_revenue DESC
LIMIT 1;


-- 6.3 Best month by revenue within each year (window function)
WITH monthly_sales AS (
    SELECT YEAR(sale_date) AS sales_year,
           MONTH(sale_date) AS sales_month,
           DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
           SUM(total_amount) AS monthly_revenue
    FROM retail_sales
    GROUP BY YEAR(sale_date), MONTH(sale_date), DATE_FORMAT(sale_date, '%Y-%m')
), ranked_months AS (
    SELECT *,
           RANK() OVER (PARTITION BY sales_year ORDER BY monthly_revenue DESC) AS revenue_rank
    FROM monthly_sales
)
SELECT sales_year, sales_month, year_month, monthly_revenue
FROM ranked_months
WHERE revenue_rank = 1
ORDER BY sales_year;


-- 6.4 Revenue by day of week
SELECT
    DAYNAME(sale_date) AS day_of_week,
    COUNT(*) AS transactions,
    SUM(total_amount) AS total_revenue
FROM retail_sales
GROUP BY DAYOFWEEK(sale_date), DAYNAME(sale_date)
ORDER BY DAYOFWEEK(sale_date);
