/* ============================================================
1. TABLE STRUCTURE & BASIC EXPLORATION
============================================================ */

-- 1.1 Confirm the selected database
SELECT DATABASE() AS current_database;


-- 1.2 Inspect table structure
DESCRIBE retail_sales;


-- 1.3 Preview the first 10 rows
SELECT *
FROM retail_sales
LIMIT 10;


-- 1.4 Total records
SELECT COUNT(*) AS total_records
FROM retail_sales;


-- 1.5 Distinct product categories
SELECT DISTINCT product_category
FROM retail_sales
ORDER BY product_category;


-- 1.6 Dataset date range
SELECT MIN(sale_date) AS first_sale_date,
       MAX(sale_date) AS last_sale_date
FROM retail_sales;
