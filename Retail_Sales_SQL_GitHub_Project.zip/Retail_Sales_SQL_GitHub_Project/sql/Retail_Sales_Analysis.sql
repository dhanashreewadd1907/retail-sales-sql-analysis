/*
RETAIL SALES ANALYSIS - MYSQL PORTFOLIO PROJECT
Dataset: Retail Sales Dataset (1,000 records)
Database: retail_sales_db
Table: retail_sales

Columns:
transaction_id, sale_date, customer_id, gender, age, product_category,
quantity, price_per_unit, total_amount

IMPORTANT:
- This script assumes the CSV has already been imported into retail_sales.
- It does NOT re-import data or delete existing records.
- Run sections/query blocks individually in MySQL Workbench to view each Result Grid.
*/

USE retail_sales_db;


/* ============================================================
1. TABLE STRUCTURE & BASIC EXPLORATION
============================================================ */

-- 1.1 Confirm the selected database
SELECT DATABASE() AS current_database;


-- 1.2 Inspect table structure
DESCRIBE retail_sales;


-- 1.3 Preview the first 10 rows
SELECT *
FROM retail_sales
LIMIT 10;


-- 1.4 Total records
SELECT COUNT(*) AS total_records
FROM retail_sales;


-- 1.5 Distinct product categories
SELECT DISTINCT product_category
FROM retail_sales
ORDER BY product_category;


-- 1.6 Dataset date range
SELECT MIN(sale_date) AS first_sale_date,
       MAX(sale_date) AS last_sale_date
FROM retail_sales;


/* ============================================================
2. DATA QUALITY CHECKS
============================================================ */

-- 2.1 Check missing values in all columns
SELECT
    COUNT(*) AS total_rows,
    SUM(transaction_id IS NULL) AS missing_transaction_id,
    SUM(sale_date IS NULL) AS missing_dates,
    SUM(customer_id IS NULL) AS missing_customer_id,
    SUM(gender IS NULL) AS missing_gender,
    SUM(age IS NULL) AS missing_age,
    SUM(product_category IS NULL) AS missing_category,
    SUM(quantity IS NULL) AS missing_quantity,
    SUM(price_per_unit IS NULL) AS missing_price,
    SUM(total_amount IS NULL) AS missing_amount
FROM retail_sales;


-- 2.2 Check duplicate transaction IDs
SELECT transaction_id, COUNT(*) AS duplicate_count
FROM retail_sales
GROUP BY transaction_id
HAVING COUNT(*) > 1;


-- 2.3 Check invalid ages, quantities, prices and amounts
SELECT *
FROM retail_sales
WHERE age < 0 OR age > 100
   OR quantity <= 0
   OR price_per_unit <= 0
   OR total_amount <= 0;


-- 2.4 Check calculation consistency: amount = quantity * unit price
SELECT transaction_id,
       quantity,
       price_per_unit,
       total_amount,
       quantity * price_per_unit AS calculated_amount
FROM retail_sales
WHERE total_amount <> quantity * price_per_unit;


/* ============================================================
3. OVERALL BUSINESS KPIs
============================================================ */

-- 3.1 Sales performance overview
SELECT
    COUNT(*) AS total_transactions,
    COUNT(DISTINCT customer_id) AS total_customers,
    SUM(quantity) AS total_units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value,
    ROUND(AVG(age), 2) AS average_customer_age
FROM retail_sales;


-- 3.2 Highest and lowest transaction values
SELECT MAX(total_amount) AS highest_transaction,
       MIN(total_amount) AS lowest_transaction
FROM retail_sales;


/* ============================================================
4. PRODUCT CATEGORY ANALYSIS
============================================================ */

-- 4.1 Revenue and quantity by product category
SELECT
    product_category,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY product_category
ORDER BY total_revenue DESC;


-- 4.2 Category contribution to total revenue (percentage)
SELECT
    product_category,
    SUM(total_amount) AS category_revenue,
    ROUND(100 * SUM(total_amount) / (SELECT SUM(total_amount) FROM retail_sales), 2)
        AS revenue_percentage
FROM retail_sales
GROUP BY product_category
ORDER BY category_revenue DESC;


-- 4.3 Most frequently purchased category by transaction count
SELECT product_category,
       COUNT(*) AS transaction_count
FROM retail_sales
GROUP BY product_category
ORDER BY transaction_count DESC;


/* ============================================================
5. CUSTOMER & DEMOGRAPHIC ANALYSIS
============================================================ */

-- 5.1 Sales performance by gender
SELECT
    gender,
    COUNT(*) AS transactions,
    COUNT(DISTINCT customer_id) AS unique_customers,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY gender
ORDER BY total_revenue DESC;


-- 5.2 Customer age group analysis
SELECT
    CASE
        WHEN age < 18 THEN 'Under 18'
        WHEN age BETWEEN 18 AND 25 THEN '18-25'
        WHEN age BETWEEN 26 AND 35 THEN '26-35'
        WHEN age BETWEEN 36 AND 45 THEN '36-45'
        WHEN age BETWEEN 46 AND 55 THEN '46-55'
        ELSE '56+'
    END AS age_group,
    COUNT(*) AS transactions,
    COUNT(DISTINCT customer_id) AS unique_customers,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY age_group
ORDER BY total_revenue DESC;


-- 5.3 Top 10 customers by revenue
SELECT
    customer_id,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_purchased,
    SUM(total_amount) AS total_spent
FROM retail_sales
GROUP BY customer_id
ORDER BY total_spent DESC
LIMIT 10;


-- 5.4 Customers with above-average total spending
SELECT customer_id,
       SUM(total_amount) AS customer_total_spending
FROM retail_sales
GROUP BY customer_id
HAVING SUM(total_amount) > (
    SELECT AVG(customer_spending)
    FROM (
        SELECT SUM(total_amount) AS customer_spending
        FROM retail_sales
        GROUP BY customer_id
    ) AS customer_totals
)
ORDER BY customer_total_spending DESC;


/* ============================================================
6. TIME-BASED SALES ANALYSIS
============================================================ */

-- 6.1 Revenue by year and month
SELECT
    YEAR(sale_date) AS sales_year,
    MONTH(sale_date) AS sales_month,
    DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS monthly_revenue
FROM retail_sales
GROUP BY YEAR(sale_date), MONTH(sale_date), DATE_FORMAT(sale_date, '%Y-%m')
ORDER BY sales_year, sales_month;


-- 6.2 Best revenue month overall
SELECT
    DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
    SUM(total_amount) AS monthly_revenue
FROM retail_sales
GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
ORDER BY monthly_revenue DESC
LIMIT 1;


-- 6.3 Best month by revenue within each year (window function)
WITH monthly_sales AS (
    SELECT YEAR(sale_date) AS sales_year,
           MONTH(sale_date) AS sales_month,
           DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
           SUM(total_amount) AS monthly_revenue
    FROM retail_sales
    GROUP BY YEAR(sale_date), MONTH(sale_date), DATE_FORMAT(sale_date, '%Y-%m')
), ranked_months AS (
    SELECT *,
           RANK() OVER (PARTITION BY sales_year ORDER BY monthly_revenue DESC) AS revenue_rank
    FROM monthly_sales
)
SELECT sales_year, sales_month, year_month, monthly_revenue
FROM ranked_months
WHERE revenue_rank = 1
ORDER BY sales_year;


-- 6.4 Revenue by day of week
SELECT
    DAYNAME(sale_date) AS day_of_week,
    COUNT(*) AS transactions,
    SUM(total_amount) AS total_revenue
FROM retail_sales
GROUP BY DAYOFWEEK(sale_date), DAYNAME(sale_date)
ORDER BY DAYOFWEEK(sale_date);


/* ============================================================
7. TRANSACTION ANALYSIS
============================================================ */

-- 7.1 Transactions above 1,000
SELECT *
FROM retail_sales
WHERE total_amount > 1000
ORDER BY total_amount DESC;


-- 7.2 Top 10 transactions by value
SELECT transaction_id, sale_date, customer_id, product_category,
       quantity, price_per_unit, total_amount
FROM retail_sales
ORDER BY total_amount DESC
LIMIT 10;


-- 7.3 Average transaction value by category
SELECT product_category,
       ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY product_category
ORDER BY average_transaction_value DESC;


/* ============================================================
8. CATEGORY x GENDER ANALYSIS
============================================================ */

-- 8.1 Transaction and revenue comparison by category and gender
SELECT
    product_category,
    gender,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY product_category, gender
ORDER BY product_category, total_revenue DESC;


/* ============================================================
9. ADVANCED SQL - RANKING & WINDOW FUNCTIONS
============================================================ */

-- 9.1 Rank product categories by revenue
SELECT
    product_category,
    SUM(total_amount) AS category_revenue,
    RANK() OVER (ORDER BY SUM(total_amount) DESC) AS revenue_rank
FROM retail_sales
GROUP BY product_category;


-- 9.2 Rank customers by total spending
WITH customer_revenue AS (
    SELECT customer_id,
           SUM(total_amount) AS total_spending
    FROM retail_sales
    GROUP BY customer_id
)
SELECT customer_id,
       total_spending,
       DENSE_RANK() OVER (ORDER BY total_spending DESC) AS customer_rank
FROM customer_revenue
ORDER BY customer_rank
LIMIT 20;


-- 9.3 Running monthly revenue total
WITH monthly_revenue AS (
    SELECT DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
           SUM(total_amount) AS revenue
    FROM retail_sales
    GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
)
SELECT year_month,
       revenue,
       SUM(revenue) OVER (ORDER BY year_month) AS running_revenue
FROM monthly_revenue
ORDER BY year_month;


-- 9.4 Revenue change compared with previous month
WITH monthly_revenue AS (
    SELECT DATE_FORMAT(sale_date, '%Y-%m') AS year_month,
           SUM(total_amount) AS revenue
    FROM retail_sales
    GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
)
SELECT year_month,
       revenue,
       LAG(revenue) OVER (ORDER BY year_month) AS previous_month_revenue,
       revenue - LAG(revenue) OVER (ORDER BY year_month) AS revenue_difference
FROM monthly_revenue
ORDER BY year_month;


/* ============================================================
10. BUSINESS QUESTIONS TO ANSWER IN PROJECT README
============================================================
1. How many transactions and unique customers are in the dataset?
2. What is the total revenue and average transaction value?
3. Which product category generates the highest revenue?
4. Which category has the highest transaction count?
5. Which gender group contributes more revenue?
6. Which customer age group contributes the most revenue?
7. Who are the top 10 customers by spending?
8. Which month generates the highest revenue?
9. Which day of the week has the highest revenue?
10. Which transactions have the highest value?
11. How do monthly revenues change over time?
12. Which categories perform best for each gender?

End of project script.
*/
