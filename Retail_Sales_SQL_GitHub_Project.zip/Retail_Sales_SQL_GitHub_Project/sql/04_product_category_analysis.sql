/* ============================================================
4. PRODUCT CATEGORY ANALYSIS
============================================================ */

-- 4.1 Revenue and quantity by product category
SELECT
    product_category,
    COUNT(*) AS transactions,
    SUM(quantity) AS units_sold,
    SUM(total_amount) AS total_revenue,
    ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY product_category
ORDER BY total_revenue DESC;


-- 4.2 Category contribution to total revenue (percentage)
SELECT
    product_category,
    SUM(total_amount) AS category_revenue,
    ROUND(100 * SUM(total_amount) / (SELECT SUM(total_amount) FROM retail_sales), 2)
        AS revenue_percentage
FROM retail_sales
GROUP BY product_category
ORDER BY category_revenue DESC;


-- 4.3 Most frequently purchased category by transaction count
SELECT product_category,
       COUNT(*) AS transaction_count
FROM retail_sales
GROUP BY product_category
ORDER BY transaction_count DESC;
