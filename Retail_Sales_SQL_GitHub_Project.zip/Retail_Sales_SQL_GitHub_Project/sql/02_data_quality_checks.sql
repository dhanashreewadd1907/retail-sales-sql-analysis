/* ============================================================
2. DATA QUALITY CHECKS
============================================================ */

-- 2.1 Check missing values in all columns
SELECT
    COUNT(*) AS total_rows,
    SUM(transaction_id IS NULL) AS missing_transaction_id,
    SUM(sale_date IS NULL) AS missing_dates,
    SUM(customer_id IS NULL) AS missing_customer_id,
    SUM(gender IS NULL) AS missing_gender,
    SUM(age IS NULL) AS missing_age,
    SUM(product_category IS NULL) AS missing_category,
    SUM(quantity IS NULL) AS missing_quantity,
    SUM(price_per_unit IS NULL) AS missing_price,
    SUM(total_amount IS NULL) AS missing_amount
FROM retail_sales;


-- 2.2 Check duplicate transaction IDs
SELECT transaction_id, COUNT(*) AS duplicate_count
FROM retail_sales
GROUP BY transaction_id
HAVING COUNT(*) > 1;


-- 2.3 Check invalid ages, quantities, prices and amounts
SELECT *
FROM retail_sales
WHERE age < 0 OR age > 100
   OR quantity <= 0
   OR price_per_unit <= 0
   OR total_amount <= 0;


-- 2.4 Check calculation consistency: amount = quantity * unit price
SELECT transaction_id,
       quantity,
       price_per_unit,
       total_amount,
       quantity * price_per_unit AS calculated_amount
FROM retail_sales
WHERE total_amount <> quantity * price_per_unit;
