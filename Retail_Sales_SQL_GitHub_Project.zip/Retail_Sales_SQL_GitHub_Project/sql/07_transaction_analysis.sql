/* ============================================================
7. TRANSACTION ANALYSIS
============================================================ */

-- 7.1 Transactions above 1,000
SELECT *
FROM retail_sales
WHERE total_amount > 1000
ORDER BY total_amount DESC;


-- 7.2 Top 10 transactions by value
SELECT transaction_id, sale_date, customer_id, product_category,
       quantity, price_per_unit, total_amount
FROM retail_sales
ORDER BY total_amount DESC
LIMIT 10;


-- 7.3 Average transaction value by category
SELECT product_category,
       ROUND(AVG(total_amount), 2) AS average_transaction_value
FROM retail_sales
GROUP BY product_category
ORDER BY average_transaction_value DESC;
