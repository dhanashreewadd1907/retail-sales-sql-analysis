Add screenshots of MySQL Workbench query results here after capturing them.
