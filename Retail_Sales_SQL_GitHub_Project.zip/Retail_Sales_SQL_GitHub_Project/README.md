# Retail Sales SQL Analysis Project

## Overview
A portfolio SQL project using MySQL to explore and analyze a retail sales dataset. The project covers table exploration, data quality validation, sales KPIs, product-category performance, customer demographics, sales trends, transaction analysis, and advanced SQL (CTEs and window functions).

## Dataset
- Dataset: Retail Sales Dataset (1,000 rows in the imported file used for this project)
- Source: Kaggle — https://www.kaggle.com/datasets/mohammadtalib786/retail-sales-dataset
- Table: `retail_sales`
- Database: `retail_sales_db`

### Columns
`transaction_id`, `sale_date`, `customer_id`, `gender`, `age`, `product_category`, `quantity`, `price_per_unit`, `total_amount`

> The dataset CSV is not included in this repository. Download it from the source and import it into MySQL before running the SQL scripts. Respect the dataset's license/terms.


## Project structure
```text
Retail_Sales_SQL_GitHub_Project/
├── README.md
├── LICENSE
├── .gitignore
├── sql/
│   ├── Retail_Sales_Analysis.sql   # complete script
│   ├── 01_basic_exploration.sql
│   ├── 02_data_quality_checks.sql
│   ├── 03_business_kpis.sql
│   ├── 04_product_category_analysis.sql
│   ├── 05_customer_demographic_analysis.sql
│   ├── 06_time_based_sales_analysis.sql
│   ├── 07_transaction_analysis.sql
│   ├── 08_category_gender_analysis.sql
│   └── 09_advanced_sql_window_functions.sql
├── data/                           # keep local CSV here; CSV is git-ignored
└── screenshots/                      # add Workbench result screenshots here
```

## Requirements
- MySQL 8.0+ (window functions are used)
- MySQL Workbench or another MySQL client
- Dataset CSV downloaded separately

## Setup
1. Create the database if needed:
   ```sql
   CREATE DATABASE retail_sales_db;
   ```
2. Import the CSV into a table named `retail_sales` using the columns and types below (or use your existing imported table):
   ```sql
   CREATE TABLE retail_sales (
       transaction_id INT PRIMARY KEY,
       sale_date DATE,
       customer_id VARCHAR(20),
       gender VARCHAR(10),
       age INT,
       product_category VARCHAR(50),
       quantity INT,
       price_per_unit DECIMAL(10,2),
       total_amount DECIMAL(10,2)
   );
   ```
3. Open `sql/Retail_Sales_Analysis.sql` in MySQL Workbench. Execute query blocks individually so each result grid can be reviewed. The script assumes the table and data already exist; it does not load or delete rows.

## Analysis sections
- Basic exploration and date/category inventory
- Missing values, duplicates, invalid values, and amount calculation checks
- Revenue, transaction, customer, quantity, and average transaction KPIs
- Category revenue and contribution share
- Customer spending and demographic breakdowns
- Monthly, yearly, and weekday trend analysis
- High-value transactions
- Category and gender comparison
- Ranking, running totals, and month-over-month comparisons using window functions

## Data quality checks performed
The imported dataset was checked in MySQL for missing values, invalid age/quantity/price/amount values, and mismatches between `total_amount` and `quantity * price_per_unit`. In the checks performed, the user observed 1,000 rows, zero missing values in the checked fields, no invalid records returned, and no amount mismatches returned. Duplicate transaction IDs should be checked with the provided query as a separate check.


## Business questions
1. How many transactions and unique customers are present?
2. What are total revenue, total units, and average transaction value?
3. Which category generates the most revenue?
4. Which category has the most transactions?
5. How does revenue vary by gender?
6. Which age groups contribute most to revenue?
7. Who are the top customers by spending?
8. Which month and weekday generate the most revenue?
9. What are the highest-value transactions?
10. How does revenue change month to month?

## Findings
Add your final measured insights here after running the KPI and analysis queries. Avoid writing conclusions until you have the actual query results.


## Tools
- MySQL 8
- MySQL Workbench
- SQL


## Author
Add your name and portfolio/contact links here before publishing.
